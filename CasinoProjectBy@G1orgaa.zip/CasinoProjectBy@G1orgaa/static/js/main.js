// Global variables
let currentGame = null;
let isProcessing = false;

// DOM Elements
const balanceValue = document.getElementById('balance-value');
const dashboardBalance = document.getElementById('dashboard-balance');
const RED_NUMBERS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);


// Utility Functions
function updateBalance(newBalance) {
    if (balanceValue) balanceValue.textContent = newBalance;
    if (dashboardBalance) dashboardBalance.textContent = newBalance;
}

function showResult(elementId, message, className) {
    const resultElement = document.getElementById(elementId);
    if (resultElement) {
        resultElement.textContent = message;
        resultElement.className = 'game-result ' + className;
    }
}

function disableButtons(disable = true) {
    const buttons = document.querySelectorAll('.btn-action, #place-bet-btn, #new-game-btn');
    buttons.forEach(btn => {
        btn.disabled = disable;
        if (disable) {
            btn.style.opacity = '0.6';
        } else {
            btn.style.opacity = '1';
        }
    });
}

// Blackjack Game Logic
function initBlackjack() {
    const hitBtn = document.getElementById('hit-btn');
    const standBtn = document.getElementById('stand-btn');
    const newGameBtn = document.getElementById('new-game-btn');
    const betAmountInput = document.getElementById('bet-amount');

    if (!hitBtn || !standBtn || !newGameBtn || !betAmountInput) return;

    // New Game
    newGameBtn.addEventListener('click', async () => {
        if (isProcessing) return;
        isProcessing = true;
        disableButtons(true); // Disable all temporarily

        const bet = parseInt(betAmountInput.value);
        if (isNaN(bet) || bet <= 0) {
            showResult('game-result', 'Please enter a valid bet amount', 'error');
            isProcessing = false;
            disableButtons(false);
            return;
        }

        try {
            const response = await fetch('/play_blackjack', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ action: 'new_game', bet: bet })
            });

            const data = await response.json();

            if (data.error) {
                showResult('game-result', data.error, 'error');
                isProcessing = false;
                disableButtons(false);
                return;
            }

            // Update UI with initial cards
            renderBlackjackCards(data);
            showResult('game-result', '', ''); // Clear previous result

            // Enable Hit and Stand
            hitBtn.disabled = false;
            standBtn.disabled = false;
            newGameBtn.disabled = false; // Keep New Game enabled

            isProcessing = false;

        } catch (error) {
            console.error('Error starting new game:', error);
            showResult('game-result', 'An error occurred. Please try again.', 'error');
            isProcessing = false;
            disableButtons(false);
        }
    });

    // Hit
    hitBtn.addEventListener('click', async () => {
        if (isProcessing) return;
        isProcessing = true;
        disableButtons(true);

        const bet = parseInt(betAmountInput.value);

        try {
            const response = await fetch('/play_blackjack', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ action: 'hit', bet: bet })
            });

            const data = await response.json();

            if (data.error) {
                showResult('game-result', data.error, 'error');
                isProcessing = false;
                disableButtons(false);
                return;
            }

            // Update UI
            renderBlackjackCards(data);
            updateBalance(data.new_balance);

            if (data.game_over) {
                showResult('game-result', `You ${data.result}! ${data.payout >= 0 ? '+' : ''}${data.payout}`, data.result);
                hitBtn.disabled = true;
                standBtn.disabled = true;
                newGameBtn.disabled = false;

            } else {

                hitBtn.disabled = false;
                standBtn.disabled = false;
            }

            isProcessing = false;
        } catch (error) {
            console.error('Error hitting:', error);
            showResult('game-result', 'An error occurred. Please try again.', 'error');
            isProcessing = false;
            disableButtons(false);
        }
    });

    // Stand
    standBtn.addEventListener('click', async () => {
        if (isProcessing) return;
        isProcessing = true;
        disableButtons(true);

        const bet = parseInt(betAmountInput.value);

        try {
            const response = await fetch('/play_blackjack', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ action: 'stand', bet: bet })
            });

            const data = await response.json();

            if (data.error) {
                showResult('game-result', data.error, 'error');
                isProcessing = false;
                disableButtons(false);
                return;
            }

            // Update UI
            renderBlackjackCards(data);
            updateBalance(data.new_balance);
            showResult('game-result', `You ${data.result}! ${data.payout >= 0 ? '+' : ''}${data.payout}`, data.result);

            isProcessing = false;
        } catch (error) {
            console.error('Error standing:', error);
            showResult('game-result', 'An error occurred. Please try again.', 'error');
            isProcessing = false;
            disableButtons(false);
        }
    });
}

function renderBlackjackCards(data) {
    const playerCards = document.getElementById('player-cards');
    const dealerCards = document.getElementById('dealer-cards');
    const playerScore = document.getElementById('player-score');
    const dealerScore = document.getElementById('dealer-score');

    if (playerCards) {
        playerCards.innerHTML = '';
        data.player_hand.forEach(cardStr => {
            const card = createCardElement(cardStr);
            playerCards.appendChild(card);
        });
    }

    if (dealerCards) {
        dealerCards.innerHTML = '';
        // Show first card face up, others face down if game not over
        data.dealer_hand.forEach((cardStr, index) => {
            if (data.game_over || index === 0) {
                const card = createCardElement(cardStr);
                dealerCards.appendChild(card);
            } else {
                const hiddenCard = document.createElement('div');
                hiddenCard.className = 'card hidden';
                hiddenCard.innerHTML = '?';
                dealerCards.appendChild(hiddenCard);
            }
        });
    }

    if (playerScore) {
        playerScore.textContent = `Score: ${data.player_score}`;
    }

    if (dealerScore) {
        if (data.game_over) {
            dealerScore.textContent = `Score: ${data.dealer_score}`;
        } else {
            dealerScore.textContent = 'Score: ?';
        }
    }
}

function createCardElement(cardStr) {
    const card = document.createElement('div');
    card.className = 'card';

    // Parse card string (e.g., "Ace of Spades")
    const parts = cardStr.split(' of ');
    const rank = parts[0];
    const suit = parts[1];

    // Determine color
    if (suit === 'Hearts' || suit === 'Diamonds') {
        card.classList.add('red');
    } else {
        card.classList.add('black');
    }

    // Map suit to symbol
    let suitSymbol = '♠';
    if (suit === 'Hearts') suitSymbol = '♥';
    else if (suit === 'Diamonds') suitSymbol = '♦';
    else if (suit === 'Clubs') suitSymbol = '♣';

    card.innerHTML = `
        <div class="rank">${rank}</div>
        <div class="suit">${suitSymbol}</div>
        <div class="rank">${rank}</div>
    `;

    return card;
}

// Roulette Game Logic
function initRoulette() {
    const placeBetBtn = document.getElementById('place-bet-btn');
    const betAmountInput = document.getElementById('roulette-bet-amount');
    const wheel = document.getElementById('roulette-wheel');
    const wheelResult = document.getElementById('wheel-result');

    let selectedBetType = null;
    let selectedBetValue = null;
    let selectedNumber = null;

    // Get all number buttons
    const numberButtons = document.querySelectorAll('.number-btn');
    const specialButtons = document.querySelectorAll('.special-btn');

    // Reset all selections
    function resetSelections() {
        numberButtons.forEach(btn => btn.classList.remove('selected'));
        specialButtons.forEach(btn => btn.classList.remove('selected'));
        selectedBetType = null;
        selectedBetValue = null;
        selectedNumber = null;
    }

    // Handle number button clicks
    numberButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            resetSelections();
            btn.classList.add('selected');
            selectedNumber = parseInt(btn.dataset.number);
            selectedBetType = 'number';
            selectedBetValue = selectedNumber;
        });
    });

    // Handle special bet button clicks
    specialButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            resetSelections();
            btn.classList.add('selected');
            selectedBetType = btn.dataset.betType;
            selectedBetValue = btn.dataset.betValue;
        });
    });

    // Place bet
    placeBetBtn.addEventListener('click', async () => {
        if (isProcessing) return;
        if (!selectedBetType || selectedBetValue === null) {
            showResult('roulette-result', 'Please select a bet', 'error');
            return;
        }

        const betAmount = parseInt(betAmountInput.value);
        if (isNaN(betAmount) || betAmount <= 0) {
            showResult('roulette-result', 'Please enter a valid bet amount', 'error');
            return;
        }

        isProcessing = true;
        disableButtons(true);

        try {
            const response = await fetch('/play_roulette', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({
                    bet_amount: betAmount,
                    bet_type: selectedBetType,
                    bet_value: selectedBetValue
                })
            });

            const data = await response.json();

            if (data.error) {
                showResult('roulette-result', data.error, 'error');
                isProcessing = false;
                disableButtons(false);
                return;
            }

            // Animate wheel
            if (wheel) {
                wheel.classList.add('spinning');
                wheel.style.transform = `rotate(${3600 + (360 - (data.spin_result * 10))}deg)`;
            }

            // Update result after animation
            setTimeout(() => {
                let resultText = `Landed on ${data.spin_result}`;
                if (data.spin_result !== 0) {
                    const redNumbers = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
                    const color = redNumbers.has(data.spin_result) ? 'Red' : 'Black';
                    resultText += ` (${color})`;
                }
                wheelResult.textContent = resultText;

                // Show game result
                const resultMessage = data.result === 'win'
                    ? `You won! +${data.payout} (x${data.multiplier})`
                    : `You lost! -${Math.abs(data.payout)}`;
                showResult('roulette-result', resultMessage, data.result);

                // Update balance
                updateBalance(data.new_balance);

                // Reset wheel animation
                if (wheel) {
                    setTimeout(() => {
                        wheel.classList.remove('spinning');
                    }, 100);
                }

                isProcessing = false;
                disableButtons(false);
                resetSelections(); // Clear selection after bet
            }, 4000);

        } catch (error) {
            console.error('Error placing bet:', error);
            showResult('roulette-result', 'An error occurred. Please try again.', 'error');
            isProcessing = false;
            disableButtons(false);
        }
    });
}

// Reset Balance
function initResetBalance() {
    const resetBtn = document.getElementById('reset-balance-btn');
    if (!resetBtn) return;

    resetBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/reset_balance', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    }
});

            const data = await response.json();

            if (data.success) {
                updateBalance(data.new_balance);
                resetBtn.style.display = 'none';
                showResult('game-result', 'Balance reset to $100!', 'success');
            } else {
                showResult('game-result', data.error || 'Failed to reset balance', 'error');
            }
        } catch (error) {
            console.error('Error resetting balance:', error);
            showResult('game-result', 'An error occurred. Please try again.', 'error');
        }
    });
}

// Initialize on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize game based on current page
    if (window.location.pathname.includes('blackjack')) {
        initBlackjack();
    } else if (window.location.pathname.includes('roulette')) {
        initRoulette();
    } else if (window.location.pathname.includes('dashboard')) {
        initResetBalance();
    }

    // Add active class to current nav item
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
});
// Enable detailed error logging
window.addEventListener('error', function(e) {
    console.error('Global error:', e.message, e.filename, e.lineno);
});