import random


class Card:
    def __init__(self, suit, rank):
        self.suit = suit
        self.rank = rank

    def __str__(self):
        return f"{self.rank} of {self.suit}"

    def value(self):
        if self.rank in ['Jack', 'Queen', 'King']:
            return 10
        elif self.rank == 'Ace':
            return 11
        else:
            return int(self.rank)


class Deck:
    def __init__(self):
        self.cards = []
        suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']

        for suit in suits:
            for rank in ranks:
                self.cards.append(Card(suit, rank))

        self.shuffle()

    def shuffle(self):
        random.shuffle(self.cards)

    def deal_card(self):
        if len(self.cards) == 0:
            self.__init__()
        return self.cards.pop()


class BlackjackGame:
    def __init__(self):
        self.deck = Deck()
        self.player_hand = []
        self.dealer_hand = []

    def deal_initial_cards(self):
        self.player_hand = [self.deck.deal_card(), self.deck.deal_card()]
        self.dealer_hand = [self.deck.deal_card(), self.deck.deal_card()]

    def player_hit(self):
        self.player_hand.append(self.deck.deal_card())

    def dealer_play(self):
        while self.dealer_score() < 17:
            self.dealer_hand.append(self.deck.deal_card())

    def calculate_hand_value(self, hand):
        value = 0
        aces = 0

        for card in hand:
            if card.rank == 'Ace':
                aces += 1
                value += 11
            else:
                value += card.value()

        while value > 21 and aces:
            value -= 10
            aces -= 1

        return value

    def player_score(self):
        return self.calculate_hand_value(self.player_hand)

    def dealer_score(self):
        return self.calculate_hand_value(self.dealer_hand)

    def player_busted(self):
        return self.player_score() > 21

    def dealer_busted(self):
        return self.dealer_score() > 21

    def determine_winner(self):
        player_score = self.player_score()
        dealer_score = self.dealer_score()

        # Check for busts
        if self.player_busted():
            return 'dealer'
        if self.dealer_busted():
            return 'player'

        if player_score > dealer_score:
            return 'player'
        elif dealer_score > player_score:
            return 'dealer'
        else:
            return 'tie'

    def to_dict(self):
        return {
            'player_hand': [(card.suit, card.rank) for card in self.player_hand],
            'dealer_hand': [(card.suit, card.rank) for card in self.dealer_hand]
        }

    @classmethod
    def from_dict(cls, data):
        game = cls()
        game.player_hand = [Card(suit, rank) for suit, rank in data['player_hand']]
        game.dealer_hand = [Card(suit, rank) for suit, rank in data['dealer_hand']]
        return game