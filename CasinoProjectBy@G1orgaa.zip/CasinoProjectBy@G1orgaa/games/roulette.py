import random


class RouletteGame:
    def __init__(self):
        self.numbers = list(range(0, 37))
        self.red_numbers = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}

    def get_color(self, number):
        if number == 0:
            return 'green'
        return 'red' if number in self.red_numbers else 'black'

    def spin_wheel(self):
        return random.choice(self.numbers)

    def check_win(self, bet_type, bet_value, spin_result):
        if bet_type == 'number':
            return str(spin_result) == str(bet_value)
        elif bet_type == 'color':
            return self.get_color(spin_result) == bet_value.lower()
        elif bet_type == 'odd_even':
            if spin_result == 0:
                return False
            if bet_value == 'odd':
                return spin_result % 2 == 1
            else:
                return spin_result % 2 == 0
        elif bet_type == 'high_low':
            if spin_result == 0:
                return False
            if bet_value == 'low':
                return 1 <= spin_result <= 18
            else:
                return 19 <= spin_result <= 36
        return False

    def get_payout_multiplier(self, bet_type):
        if bet_type == 'number':
            return 35
        elif bet_type in ['color', 'odd_even', 'high_low']:
            return 1
        return 0