from flask import Blueprint, render_template, redirect, url_for, request, jsonify, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import User
from extensions import db
from forms import RegistrationForm, LoginForm
from games.roulette import RouletteGame
import random

routes = Blueprint('routes', __name__)


@routes.route('/index')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('routes.dashboard'))
    return render_template('index.html')


@routes.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('routes.dashboard'))

    form = RegistrationForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user:
            flash('Username already exists. Please choose a different one.', 'error')
            return render_template('register.html', form=form)

        hashed_password = generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, password_hash=hashed_password, balance=100)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('routes.login'))

    return render_template('register.html', form=form)


@routes.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('routes.dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()

        if not user or not check_password_hash(user.password_hash, form.password.data):
            flash('Invalid username or password.', 'error')
            return render_template('login.html', form=form)

        login_user(user)
        return redirect(url_for('routes.dashboard'))

    return render_template('login.html', form=form)


@routes.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('routes.index'))


@routes.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=current_user)


@routes.route('/blackjack')
@login_required
def blackjack():
    return render_template('blackjack.html', user=current_user)


@routes.route('/roulette')
@login_required
def roulette():
    return render_template('roulette.html', user=current_user)



@routes.route('/play_roulette', methods=['POST'])
@login_required
def play_roulette():

    try:
        data = request.get_json()
        bet_amount = int(data.get('bet_amount', 0))
        bet_type = data.get('bet_type')
        bet_value = data.get('bet_value')


        if bet_amount <= 0:
            return jsonify({'error': 'Bet must be greater than 0'}), 400

        if bet_amount > current_user.balance:
            return jsonify({'error': 'Insufficient balance'}), 400

        game = RouletteGame()
        spin_result = game.spin_wheel()
        is_win = game.check_win(bet_type, bet_value, spin_result)

        if is_win:
            multiplier = game.get_payout_multiplier(bet_type)
            payout = bet_amount * multiplier
            result = 'win'
        else:
            payout = -bet_amount
            result = 'lose'

        current_user.balance += payout
        db.session.commit()

        response = {
            'spin_result': spin_result,
            'result': result,
            'payout': payout,
            'new_balance': current_user.balance,
            'multiplier': game.get_payout_multiplier(bet_type) if is_win else 0
        }

        return jsonify(response)

    except Exception as e:
        return jsonify({'error': str(e)}), 500



@routes.route('/reset_balance', methods=['POST'])
@login_required
def reset_balance():
    if current_user.balance <= 0:
        current_user.balance = 100
        db.session.commit()
        return jsonify({'success': True, 'new_balance': 100})
    return jsonify({'success': False, 'error': 'Balance is not zero'}), 400

games = {}

def create_deck():
    suits = ['♠', '♥', '♦', '♣']
    values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
    deck = [{'suit': s, 'value': v} for s in suits for v in values]
    random.shuffle(deck)
    return deck

@routes.route('/api/blackjack/new_game', methods=['GET'])
def new_game():
    user_id = request.args.get('user_id', 'default')
    games[user_id] = {
        'deck': create_deck(),
        'player_hand': [],
        'dealer_hand': [],
        'bet': 100,
        'balance': 2500,
        'active': True,
        'player_turn': True,
        'wins': 5,
        'losses': 3,
        'draws': 1
    }
    game = games[user_id]

    # Deal initial cards
    game['player_hand'] = [game['deck'].pop(), game['deck'].pop()]
    game['dealer_hand'] = [game['deck'].pop(), game['deck'].pop()]

    return jsonify({
        'success': True,
        'player_hand': game['player_hand'],
        'dealer_hand': [game['dealer_hand'][0], {'value': '?', 'suit': '?'}],  # Hide first card
        'bet': game['bet'],
        'balance': game['balance'],
        'wins': game['wins'],
        'losses': game['losses'],
        'draws': game['draws'],
        'dealer_up_card': game['dealer_hand'][1],
        'player_total': calculate_hand_total(game['player_hand']),
        'dealer_total': '?'
    })


@routes.route('/api/blackjack/hit', methods=['POST'])
def hit():
    user_id = request.json.get('user_id', 'default')
    game = games.get(user_id)
    if not game or not game['active']:
        return jsonify({'error': 'Game not active'})

    if len(game['deck']) == 0:
        game['deck'] = create_deck()

    card = game['deck'].pop()
    game['player_hand'].append(card)

    player_total = calculate_hand_total(game['player_hand'])
    if player_total > 21:
        game['active'] = False
        game['losses'] += 1
        game['balance'] -= game['bet']
        result = 'bust'
    else:
        result = 'continue'

    return jsonify({
        'success': True,
        'card': card,
        'player_hand': game['player_hand'],
        'player_total': player_total,
        'result': result,
        'balance': game['balance'],
        'wins': game['wins'],
        'losses': game['losses'],
        'draws': game['draws']
    })


@routes.route('/api/blackjack/stand', methods=['POST'])
def stand():
    user_id = request.json.get('user_id', 'default')
    game = games.get(user_id)
    if not game or not game['active']:
        return jsonify({'error': 'Game not active'})

    game['player_turn'] = False

    # Dealer plays
    while calculate_hand_total(game['dealer_hand']) < 17:
        if len(game['deck']) == 0:
            game['deck'] = create_deck()
        game['dealer_hand'].append(game['deck'].pop())

    player_total = calculate_hand_total(game['player_hand'])
    dealer_total = calculate_hand_total(game['dealer_hand'])

    if player_total > 21:
        game['losses'] += 1
        game['balance'] -= game['bet']
        result = 'loss'
    elif dealer_total > 21:
        game['wins'] += 1
        game['balance'] += game['bet']
        result = 'win'
    elif player_total > dealer_total:
        game['wins'] += 1
        game['balance'] += game['bet']
        result = 'win'
    elif player_total < dealer_total:
        game['losses'] += 1
        game['balance'] -= game['bet']
        result = 'loss'
    else:
        game['draws'] += 1
        game['balance'] += game['bet']  # Return bet
        result = 'draw'

    game['active'] = False

    return jsonify({
        'success': True,
        'dealer_hand': game['dealer_hand'],
        'dealer_total': dealer_total,
        'result': result,
        'balance': game['balance'],
        'wins': game['wins'],
        'losses': game['losses'],
        'draws': game['draws']
    })


def calculate_hand_total(hand):
    total = 0
    aces = 0

    for card in hand:
        if card['value'] == 'A':
            total += 11
            aces += 1
        elif card['value'] in ['K', 'Q', 'J']:
            total += 10
        else:
            total += int(card['value'])

    while total > 21 and aces > 0:
        total -= 10
        aces -= 1

    return total
